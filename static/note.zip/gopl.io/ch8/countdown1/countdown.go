// Copyright © 2016 Alan A. A. Donovan & Brian W. Kernighan.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/

// See page 244.

// Countdown implements the countdown for a rocket launch.
package main

import (
	"fmt"
	"io"
	"log"
	"os"
)

//!+
func main() {
	//fmt.Println("Commencing countdown.")
	//tick := time.Tick(1 * time.Second)
	doneCh := make(chan struct{})
	go func() {
		//var i = new(int)
		w, _ := io.Copy(os.Stdout, os.Stdin)
		fmt.Print(w)
	}()

	<-doneCh
	//for countdown := 10; countdown > 0; countdown-- {
	//	fmt.Println(countdown)
	//	<-tick
	//}
	//launch()
}

//!-

func mustCopy(dst io.Writer, src io.Reader) {
	fmt.Println("3")
	if _, err := io.Copy(dst, src); err != nil {
		fmt.Println("4")
		log.Fatal(err)
	}
}
