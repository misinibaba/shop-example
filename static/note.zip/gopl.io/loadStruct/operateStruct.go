//SimpleStruct 简单结构，帮助table 2 struct
//@param tbl string 表名
package main

func main() {

}
